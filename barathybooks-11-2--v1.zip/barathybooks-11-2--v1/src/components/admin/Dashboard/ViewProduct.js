import React, { useEffect, useState } from 'react';
import { db } from '../../../firebase/config';
import { collection, getDocs, deleteDoc, doc } from "firebase/firestore";
import { IconButton, Button, Typography, Box, Grid, Paper } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';

function ViewProduct() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [categoryCounts, setCategoryCounts] = useState({});

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, "products"));
        const productsList = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
        console.log("Fetched products:", productsList); // Debugging log
        setProducts(productsList);

        // Calculate category counts
        const counts = productsList.reduce((acc, product) => {
          acc[product.category] = (acc[product.category] || 0) + 1;
          return acc;
        }, {});
        setCategoryCounts(counts);
      } catch (error) {
        console.error("Error fetching products: ", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const handleDelete = async (id) => {
    try {
      await deleteDoc(doc(db, "products", id));
      setProducts(products.filter(product => product.id !== id));
      console.log(`Product with id ${id} deleted`); // Debugging log
    } catch (error) {
      console.error("Error deleting product: ", error);
    }
  };

  if (loading) {
    return <p>Loading products...</p>;
  }

  return (
    <div>
      <Box sx={{ p: 3 }}>
        <Typography variant="h4" gutterBottom>
          Products Summary
        </Typography>
        <Paper sx={{ p: 2, mb: 3 }}>
          <Typography variant="h6">Total Products: {products.length}</Typography>
          <Grid container spacing={2}>
            {Object.keys(categoryCounts).map((category) => (
              <Grid item xs={12} sm={6} md={4} key={category}>
                <Typography variant="body1">
                  {category}: {categoryCounts[category]}
                </Typography>
              </Grid>
            ))}
          </Grid>
        </Paper>
        <div className="products-container">
          {products.length === 0 ? (
            <p>No products found.</p>
          ) : (
            products.map((product) => (
              <div className="product-card" key={product.id}>
                <img src={product.imageUrl} alt={product.name} />
                <h2>{product.name}</h2>
                <p>{product.description}</p>
                <p>${product.price}</p>
                <p>Category: {product.category}</p>
                <p>Visibility: {product.visibility ? "Public" : "Private"}</p>
                <IconButton aria-label="delete" size="large" onClick={() => handleDelete(product.id)}>
                  <DeleteIcon fontSize="inherit" />
                </IconButton>
                <Button variant="contained" href={`/edit-product/${product.id}`}>
                  Edit
                </Button>
              </div>
            ))
          )}
        </div>
      </Box>
    </div>
  );
}

export default ViewProduct;
