import React, { useState } from 'react';
import { db } from '../../../firebase/config';
import { collection, addDoc } from "firebase/firestore";
import * as XLSX from 'xlsx';
import { TextField, Button, Checkbox, FormControlLabel, Select, MenuItem, InputLabel, Alert, Box, Typography, Grid, Paper } from '@mui/material';
import { styled } from '@mui/material/styles';

const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(3),
  backgroundColor: theme.palette.background.default,
  boxShadow: theme.shadows[3],
  borderRadius: theme.shape.borderRadius,
}));

const StyledButton = styled(Button)(({ theme }) => ({
  marginTop: theme.spacing(2),
  backgroundColor: theme.palette.primary.main,
  color: theme.palette.primary.contrastText,
  '&:hover': {
    backgroundColor: theme.palette.primary.dark,
  },
}));

function UploadProducts() {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [message, setMessage] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [visibility, setVisibility] = useState(false);
  const [category, setCategory] = useState(""); // New state for category
  const [bulkMessage, setBulkMessage] = useState(""); // New state for bulk upload message

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, "products"), {
        name,
        price,
        description,
        imageUrl,
        visibility,
        category // Include category in the product data
      });
      setMessage("Product uploaded successfully!");
      setName("");
      setPrice("");
      setDescription("");
      setImageUrl("");
      setVisibility(false);
      setCategory(""); // Reset category
    } catch (error) {
      console.error("Error uploading product: ", error);
      setMessage("Error uploading product. Please try again.");
    }
  };

  const handleBulkUpload = async (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = async (event) => {
      const data = new Uint8Array(event.target.result);
      const workbook = XLSX.read(data, { type: 'array' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);

      try {
        for (const product of jsonData) {
          await addDoc(collection(db, "products"), {
            name: product.name,
            price: product.price,
            description: product.description,
            imageUrl: product.imageUrl,
            visibility: product.visibility,
            category: product.category
          });
        }
        setBulkMessage("Bulk upload successful!");
      } catch (error) {
        console.error("Error uploading products: ", error);
        setBulkMessage("Error uploading products. Please try again.");
      }
    };
    reader.readAsArrayBuffer(file);
  };

  return (
    <Box sx={{ p: 3 }}>
      {message && (
        <Alert severity={message.includes("successfully") ? "success" : "error"} sx={{ mb: 2 }}>
          {message}
        </Alert>
      )}
      <Typography variant="h4" gutterBottom>
        Upload Products
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <StyledPaper>
            <form onSubmit={handleSubmit}>
              <TextField
                label="Product Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                fullWidth
                margin="normal"
              />
              <TextField
                label="Price"
                type="number"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                required
                fullWidth
                margin="normal"
              />
              <TextField
                label="Description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                fullWidth
                margin="normal"
                multiline
                rows={4}
              />
              <TextField
                label="Image URL"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                required
                fullWidth
                margin="normal"
              />
              <FormControlLabel
                control={
                  <Checkbox
                    checked={visibility}
                    onChange={(e) => setVisibility(e.target.checked)}
                  />
                }
                label="Publish"
              />
              <InputLabel id="category-label">Category</InputLabel>
              <Select
                labelId="category-label"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                required
                fullWidth
                margin="normal"
              >
                <MenuItem value="" disabled>Select Category</MenuItem>
                <MenuItem value="Fiction">Fiction</MenuItem>
                <MenuItem value="Non-Fiction">Non-Fiction</MenuItem>
                <MenuItem value="Science-Fiction">Science-Fiction</MenuItem>
                <MenuItem value="History">History</MenuItem>
                <MenuItem value="Fantasy">Fantasy</MenuItem>
                <MenuItem value="Competitive-books">Competitive books</MenuItem>
                <MenuItem value="Self-help">Self-Help-personal development</MenuItem>
                <MenuItem value="Children's-Books">Children's Books</MenuItem>
                <MenuItem value="bio-auto">Biography and Autobiography</MenuItem>
                {/* Add more categories as needed */}
              </Select>
              <StyledButton type="submit" variant="contained" fullWidth>
                Upload
              </StyledButton>
            </form>
          </StyledPaper>
        </Grid>
        <Grid item xs={12} md={6}>
          <StyledPaper>
            <Typography variant="h5" gutterBottom>
              Bulk Upload
            </Typography>
            <input type="file" accept=".csv, .xlsx, .xls" onChange={handleBulkUpload} />
            {bulkMessage && (
              <Alert severity={bulkMessage.includes("successful") ? "success" : "error"} sx={{ mt: 2 }}>
                {bulkMessage}
              </Alert>
            )}
          </StyledPaper>
        </Grid>
      </Grid>
    </Box>
  );
}

export default UploadProducts;
