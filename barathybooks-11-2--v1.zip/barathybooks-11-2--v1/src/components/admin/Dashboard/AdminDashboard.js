import React from 'react';
import { AppBar, Toolbar, Typography, Drawer, List, ListItem, ListItemIcon, ListItemText, CssBaseline, Box } from '@mui/material';
import { Dashboard, Upload, ListAlt, People, Settings as SettingsIcon, Visibility } from '@mui/icons-material';
import { styled } from '@mui/material/styles';
import { useNavigate, Outlet } from 'react-router-dom';

const drawerWidth = 240;

const Root = styled('div')(({ theme }) => ({
  display: 'flex',
  height: '100vh',
}));

const AppBarStyled = styled(AppBar)(({ theme }) => ({
  zIndex: theme.zIndex.drawer + 1,
}));

const DrawerStyled = styled(Drawer)(({ theme }) => ({
  width: drawerWidth,
  flexShrink: 0,
  '& .MuiDrawer-paper': {
    width: drawerWidth,
  },
}));

const Content = styled('main')(({ theme }) => ({
  flexGrow: 1,
  padding: theme.spacing(3),
  overflow: 'auto',
}));

const ToolbarStyled = styled('div')(({ theme }) => theme.mixins.toolbar);

function AdminDashboard() {
  const navigate = useNavigate();

  const menuItems = [
    { text: 'Dashboard', icon: <Dashboard />, path: '/dashboard' },
    { text: 'Upload Products', icon: <Upload />, path: '/dashboard/upload-products' },
    { text: 'Order Details', icon: <ListAlt />, path: '/dashboard/order-details' },
    { text: 'Manage Users', icon: <People />, path: '/dashboard/manage-users' },
    { text: 'Settings', icon: <SettingsIcon />, path: '/dashboard/settings' },
    { text: 'View Products', icon: <Visibility />, path: '/dashboard/view-products' },
  ];

  return (
    <Root>
      <CssBaseline />
      <AppBarStyled position="fixed">
        <Toolbar>
          <Typography variant="h6" noWrap>
            Admin Dashboard
          </Typography>
        </Toolbar>
      </AppBarStyled>
      <DrawerStyled variant="permanent">
        <ToolbarStyled />
        <List>
          {menuItems.map((item, index) => (
            <ListItem button key={index} onClick={() => navigate(item.path)}>
              <ListItemIcon>{item.icon}</ListItemIcon>
              <ListItemText primary={item.text} />
            </ListItem>
          ))}
        </List>
      </DrawerStyled>
      <Content>
        <ToolbarStyled />
        <Outlet />
      </Content>
    </Root>
  );
}

export default AdminDashboard;
